$(function(){
	
	
	$('.place').each(function(){
		<!-- Colocando o valor Do Place Dentro do Title para realizar o PlaceHolder De Maneira Interativa -->
		
		
    var place = $(this).attr('title');	
var input = $(this);


input
.val(place)	
.css('color','#ccc')
<!-- Colocando o input escondido quando for selecionado -->

.focusin(function(){
	input.css('color','#000');
	if(input.val() == place){
	input.val('');
	}
	
}).focusout(function(){
	if(input.val() == ''){
		input.css('color','#ccc');
		input.val(place);
		
	}
});
		
	});
	var ex = $('.ex1');
	/* $('.key').keypress(function(){
		ex.text($(this).val()); */
		
		/* $('.key').keydown(function(){
			ex.text($(this).val()); */
			
			$('.key').keyup(function(){
			ex.text($(this).val());
			
		});
		
	
});